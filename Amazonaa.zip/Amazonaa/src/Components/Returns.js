import '../App.css'


function Returnit() {
    return (
        <div>
            <h2>Return orders</h2>
        </div>
    )
}

export default Returnit;